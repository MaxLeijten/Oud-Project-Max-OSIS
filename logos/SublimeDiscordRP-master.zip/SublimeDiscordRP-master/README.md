<center>
<img align="left" src="https://cdn.discordapp.com/app-assets/389368374645227520/389408211133923328.png">
<h1>Sublime Discord Rich Presence</h1>
</center>

Discord Rich Presence for Sublime Text 3.  
</br>
<hr>

## Preview

|  User Modal  | Popout Modal
| ------------ | ------------------------------------------
| ![](https://i-need.discord.cards/fc30f4.png) | ![](https://i-need.discord.cards/c408bd.png)


## Installation

The recommended installation method is to use [Package Control](https://packagecontrol.io/packages/Discord%20Rich%20Presence).

![Animation of installation through Package Control](https://camo.githubusercontent.com/ff3df50a4bad4b83b2072550c1d8cf6f5d55d159/68747470733a2f2f692e696d6775722e636f6d2f737a7475474f572e676966)

If for any reason you want to install the package manually, ensure that the package's folder is named `Discord Rich Presence`.

## Usage

Open the Command Palette and select the <kbd>Discord Rich Presence: Connect to Discord</kbd> command.
You should also check out the settings through <kbd>Preferences: Discord Rich Presence Settings</kbd>, where you can enable auto-connect.
